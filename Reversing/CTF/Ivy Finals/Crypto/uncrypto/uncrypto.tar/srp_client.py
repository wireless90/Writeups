import hashlib
import random
import socket
import sys
import struct
import time

USAGE = """Usage:\nsrp_client.py server_ip server_port operation user pass
operation: register / auth
"""

# This is the client implementation of the SRV protocol.
# The client can issue a register request to the server:
#
# python srp_client.py register 'username' 'password'
#
# and he can authenticate himself afterwards using
# the SRP authentication protocol by issuing:
#
# python srp_client.py authenticate 'username' 'password'
#
# If the authentication process succeeds the protocol
# will yield a common session key
#
# The notation from http://srp.stanford.edu/design.html is used


# Reference: https://en.wikipedia.org/wiki/Secure_Remote_Password_protocol
def H(*a):  # a one-way hash function
    a = ':'.join([str(a) for a in a])
    return int(hashlib.sha256(a.encode('ascii')).hexdigest(), 16)

# Reference: https://en.wikipedia.org/wiki/Secure_Remote_Password_protocol
def cryptrand(n=1024):
    return random.SystemRandom().getrandbits(n) % N

# We assume that Client and Server have agreed on
# a generator, public modulus, hash function, multiplier parameter 
N = '''00:c0:37:c3:75:88:b4:32:98:87:e6:1c:2d:a3:32:
       4b:1b:a4:b8:1a:63:f9:74:8f:ed:2d:8a:41:0c:2f:
       c2:1b:12:32:f0:d3:bf:a0:24:27:6c:fd:88:44:81:
       97:aa:e4:86:a6:3b:fc:a7:b8:bf:77:54:df:b3:27:
       c7:20:1f:6f:d1:7f:d7:fd:74:15:8b:d3:1c:e7:72:
       c9:f5:f8:ab:58:45:48:a9:9a:75:9b:5a:2c:05:32:
       16:2b:7b:62:18:e8:f1:42:bc:e2:c3:0d:77:84:68:
       9a:48:3e:09:5e:70:16:18:43:79:13:a8:c3:9c:3d:
       d0:d4:ca:3c:50:0b:88:5f:e3'''
N = int(''.join(N.split()).replace(':', ''), 16) # public modulus

g = 2        # generator
k = H(N, g)  # multiplier parameter

def recv_line(sock):
    # Returns line without the newline
    inp = b''
    while True:
        data = sock.recv(1)
        if not data:
            raise RuntimeError("socket disc?")
        if b'\n' == data:
            return inp
        inp += data

# Register sends a request to the Server containing v, s
def register(sock, username, password):
    I = username         # Username
    p = password         # Password
    s = cryptrand(64)    # Salt 
    x = H(s, I, p)       # Private key
    v = pow(g, x, N)     # Password verifier

    # Register by sending (I, s, v) to the server
    sock.send(("register {} {} {}\n".format(I, s, v)).encode())
    print(recv_line(sock))

def authenticate(sock, username, password):
    I = username         # Username
    p = password         # Password
    a = cryptrand()      # Secret ephemeral value
    A = pow(g, a, N)     # Public ephemeral value

    # Authenticate by sending (I, A) to the server
    sock.send(("authenticate {} {}\n".format(username, A)).encode())

    # Check Response
    s = recv_line(sock)
    if s == b"Error: Could not find username in database":
        print(s)
    else:
        # Generate session key
        s = int(s)
        B = int(recv_line(sock))
        
        u = H(A, B)      # Random scrambling parameter
        x = H(s, I, p)
        S_c = pow(B - k * pow(g, x, N), a + u * x, N)
        K_c = H(S_c)

        # Verification process
        M_c = H(H(N) ^ H(g), H(I), s, A, B, K_c)
        sock.send(("{}\n".format(str(M_c))).encode())

        M_s_server = int(recv_line(sock))
        M_s_client = H(A, M_c, K_c)

        # Check equality of keys
        if M_s_server == M_s_client:
            print("Authentication done and Sessionkey established:")
            print(K_c)
            
            msg = recv_line(sock)
            print(msg)
            flag = recv_line(sock)
            print(flag)
        else:
            print("Something went wrong in the authentication process:")

def establish_conn(host, port):
    # Connect to server
    for i in range(2):
        try:
            sock = socket.socket()
            sock.connect((host, port))
            return sock            
        except:
            time.sleep(1)
    raise RuntimeError("Failed to connect to server")


def main():
    sock = socket.socket()

    host = sys.argv[1]
    port = int(sys.argv[2])

    sock = establish_conn(host, port)
    sock.settimeout(5)

    # Generates arguments as specified in the top of the document
    if sys.argv[3] == 'register':
        register(sock, sys.argv[4], sys.argv[5])
    elif sys.argv[3] == 'auth':
        authenticate(sock, sys.argv[4], sys.argv[5])
    else:
        print("No operation requested...")

    sock.close()

if '__main__' == __name__:
    print(USAGE)
    main()